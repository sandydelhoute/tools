$EmailFrom = "me@localhost.fr�
$EmailTo = "you@localhost.fr�
$Subject = "Sujet mail�
$Body = "�a marche !�
$SMTPServer = "localhost�
$SMTPClient = New-Object Net.Mail.SmtpClient($SmtpServer, 25)
$SMTPClient.Send($EmailFrom, $EmailTo, $Subject, $Body)